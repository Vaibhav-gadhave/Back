#!/bin/bash
data=`whoami`
if [[ $UID -ge 500 ]]; then
   `cp -a /vncremote/.config /home/$data/`   
  fi
